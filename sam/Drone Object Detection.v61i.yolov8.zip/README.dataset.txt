# Drone Object Detection > 2024-04-14 10:09pm
https://universe.roboflow.com/drone-obstacle-detection/drone-object-detection-yhpn6

Provided by a Roboflow user
License: CC BY 4.0

